# 🖥️ LABORATÓRIO DE INFORMÁTICA

## Instalação, Configuração, Testes e Validação dos Softwares

> **Documento de referência para instalação, configuração, testes e preparação das máquinas do Laboratório de Informática antes do congelamento (freeze) da imagem.**

---

## 📋 Índice

* [🎯 Objetivo](#-objetivo)
* [💻 Desenvolvimento e IDEs](#-desenvolvimento-e-ides)
* [🧩 Extensões Principais para o VS Code](#-extensões-principais-para-o-vs-code)
* [🗄️ Bancos de Dados](#️-bancos-de-dados)
* [☕ Linguagens e Ambientes de Execução](#-linguagens-e-ambientes-de-execução)
* [📦 Controle de Versão](#-controle-de-versão)
* [📐 Modelagem UML e Design](#-modelagem-uml-e-design)
* [🧠 Algoritmos e Programação](#-algoritmos-e-programação)
* [🎨 Edição Gráfica](#-edição-gráfica)
* [🎬 Áudio, Vídeo e Gravação](#-áudio-vídeo-e-gravação)
* [🛠️ Utilitários](#️-utilitários)
* [🤖 Android Studio, SDK, Emulador e Gradle](#-android-studio-sdk-emulador-e-gradle)
* [🧪 Projetos Android de Teste](#-projetos-android-de-teste)
* [🗄️ Configuração dos Serviços de Banco de Dados](#️-configuração-dos-serviços-de-banco-de-dados)
* [🔧 Scripts Windows](#-scripts-windows)
* [🔍 Script de Verificação de Versões](#-script-de-verificação-de-versões)
* [🧪 Teste Final do Laboratório](#-teste-final-do-laboratório)
* [❄️ Freeze da Imagem](#️-freeze-da-imagem)
* [✅ Checklist Final](#-checklist-final)

---

# 🎯 Objetivo

Este documento tem como finalidade centralizar os softwares, versões, links de instalação, extensões, configurações, scripts e procedimentos necessários para preparar os computadores do Laboratório de Informática.

O ambiente deverá atender às necessidades das disciplinas de:

* Programação;
* Desenvolvimento de sistemas;
* Java;
* Python;
* JavaScript;
* Node.js;
* Banco de dados;
* Desenvolvimento Android;
* UML e modelagem;
* Algoritmos;
* Design;
* Edição gráfica;
* Áudio e vídeo;
* Controle de versão;
* Containers e Docker.

Antes do congelamento da imagem das máquinas, todos os softwares e ambientes deverão ser instalados e testados em uma **máquina modelo**.

---

# 💻 Desenvolvimento e IDEs

| NOME                    | VERSÃO          | DESCRIÇÃO                                                                                       | LINK                                                                                 |
| ----------------------- | --------------- | ----------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| VS Code                 | Atual           | Editor de código-fonte leve e extensível.                                                       | https://code.visualstudio.com/                                                       |
| IntelliJ IDEA Community | 2023.1          | IDE focada em desenvolvimento Java e Kotlin.                                                    | https://download.jetbrains.com/idea/ideaIC-2023.1.7.exe                              |
| PyCharm Community       | 2023.1          | IDE focada em desenvolvimento Python profissional.                                              | https://download-cdn.jetbrains.com/python/pycharm-community-2023.1.6.exe             |
| Android Studio          | 2023 (Hedgehog) | IDE oficial para desenvolvimento de aplicativos Android. Com Emulador testado p/ Java e Kotlin. | https://download2.fileeagle.com/files/2023/12/android-studio-2023.1.1.26-windows.exe |
| Code::Blocks            | 20.03           | IDE para C/C++ (inclui compilador MinGW).                                                       | https://sourceforge.net/projects/codeblocks/files/Binaries/20.03/Windows/            |
| Arduino IDE             | 2               | Ambiente de desenvolvimento para Arduino.                                                       | https://downloads.arduino.cc/arduino-ide/arduino-ide_latest_Windows_64bit.exe        |
| Notepad++               | Atual           | Editor de texto avançado e versátil.                                                            | https://notepad-plus-plus.org/downloads/                                             |

---

# 🧩 Extensões Principais para o VS Code

| NOME                        | VERSÃO   | DESCRIÇÃO                                                       | LINK                                                                               |
| --------------------------- | -------- | --------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| VS Code Java Extension Pack | Extensão | Conjunto de extensões para desenvolvimento Java no VS Code.     | https://marketplace.visualstudio.com/items?itemName=vscjava.vscode-java-pack       |
| Spring Boot Extension Pack  | Extensão | Suporte para Spring Boot no VS Code.                            | https://marketplace.visualstudio.com/items?itemName=vmware.vscode-boot-dev-pack    |
| Python Extension (VS Code)  | Extensão | Suporte completo para a linguagem Python no VS Code.            | https://marketplace.visualstudio.com/items?itemName=ms-python.python               |
| Pylance                     | Extensão | Suporte avançado para Python, análise de código e IntelliSense. | https://marketplace.visualstudio.com/items?itemName=ms-python.vscode-pylance       |
| Python Debugger             | Extensão | Ferramentas para depuração de aplicações Python.                | https://marketplace.visualstudio.com/items?itemName=ms-python.debugpy              |
| ESLint                      | Extensão | Análise e padronização de código JavaScript/TypeScript.         | https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint         |
| Prettier - Code formatter   | Extensão | Formatação automática de código.                                | https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode         |
| Node.js Extension Pack      | Extensão | Conjunto de extensões para desenvolvimento Node.js.             | https://marketplace.visualstudio.com/items?itemName=waderyan.nodejs-extension-pack |
| Docker                      | Extensão | Suporte para desenvolvimento utilizando Docker.                 | https://marketplace.visualstudio.com/items?itemName=ms-azuretools.vscode-docker    |
| GitLens                     | Extensão | Recursos avançados para Git dentro do VS Code.                  | https://marketplace.visualstudio.com/items?itemName=eamodio.gitlens                |
| Live Server                 | Extensão | Servidor local para desenvolvimento web.                        | https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer          |
| HTML CSS Support            | Extensão | Suporte para HTML e CSS.                                        | https://marketplace.visualstudio.com/items?itemName=ecmel.vscode-html-css          |
| REST Client                 | Extensão | Permite executar requisições HTTP diretamente no VS Code.       | https://marketplace.visualstudio.com/items?itemName=humao.rest-client              |
| Code Runner                 | Extensão | Execução rápida de códigos diretamente no VS Code.              | https://marketplace.visualstudio.com/items?itemName=formulahendry.code-runner      |

### Instalação das extensões

Após instalar o VS Code, verificar as extensões:

```bat
code --list-extensions
```

Instalação pelo terminal:

```bat
code --install-extension vscjava.vscode-java-pack
code --install-extension vmware.vscode-boot-dev-pack
code --install-extension ms-python.python
code --install-extension ms-python.vscode-pylance
code --install-extension ms-python.debugpy
code --install-extension dbaeumer.vscode-eslint
code --install-extension esbenp.prettier-vscode
code --install-extension waderyan.nodejs-extension-pack
code --install-extension ms-azuretools.vscode-docker
code --install-extension eamodio.gitlens
code --install-extension ritwickdey.LiveServer
code --install-extension ecmel.vscode-html-css
code --install-extension humao.rest-client
code --install-extension formulahendry.code-runner
```

---

# 🗄️ Bancos de Dados

| NOME                      | VERSÃO      | DESCRIÇÃO                                                            | LINK                                                                        |
| ------------------------- | ----------- | -------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| MySQL Community           | 8.0.x (LTS) | Banco de dados relacional. Recomenda-se desativar o serviço no boot. | https://dev.mysql.com/downloads/mysql/8.0.html                              |
| MySQL Workbench           | 8.0.x       | Ferramenta visual para design e gestão de MySQL.                     | https://dev.mysql.com/downloads/workbench/                                  |
| PostgreSQL                | 17.x        | Banco de dados relacional. Recomenda-se desativar o serviço no boot. | https://sbp.enterprisedb.com/getfile.jsp?fileid=1260116                     |
| pgAdmin 4                 | v8.14       | Ferramenta de administração e gestão para PostgreSQL.                | https://www.postgresql.org/ftp/pgadmin/pgadmin4/v8.14/windows/              |
| MongoDB Community Edition | 7.0         | Banco de dados NoSQL.                                                | https://fastdl.mongodb.org/windows/mongodb-windows-x86_64-8.0.20-signed.msi |
| MongoDB Compass           | 1.40.x      | Interface gráfica para MongoDB.                                      | https://downloads.mongodb.com/compass/mongodb-compass-1.49.4-win32-x64.exe  |
| DBeaver CE                | 23.x        | Ferramenta universal de banco de dados e cliente SQL.                | https://dbeaver.io/files/23.3.5/dbeaver-ce-23.3.5-x86_64-setup.exe          |
| Cassandra                 | DB          | Será instalado via Docker.                                           | https://cassandra.apache.org/_/download.html                                |

---

# ☕ Linguagens e Ambientes de Execução

| NOME           | VERSÃO        | DESCRIÇÃO                                        | LINK                                                                        |
| -------------- | ------------- | ------------------------------------------------ | --------------------------------------------------------------------------- |
| Node.js        | 22.22.x (LTS) | Ambiente de execução JavaScript server-side.     | https://nodejs.org/dist/v22.22.1/node-v22.22.1-x64.msi                      |
| Python         | 3.13 (LTS)    | Linguagem de programação de alto nível.          | https://www.python.org/ftp/python/3.13.13/python-3.13.13-amd64.exe          |
| Java JDK       | 21 (LTS)      | Kit de desenvolvimento Java (Long Term Support). | https://download.oracle.com/java/21/archive/jdk-21.0.10_windows-x64_bin.exe |
| Docker Desktop | Atual         | Ferramenta para criação e gestão de containers.  | https://www.docker.com/products/docker-desktop/                             |

### Verificação

```bat
java -version
javac -version

python --version
python -m pip --version

node --version
npm --version
npx --version

docker --version
docker compose version
```

---

# 📦 Controle de Versão

| NOME           | VERSÃO | DESCRIÇÃO                                               | LINK                                 |
| -------------- | ------ | ------------------------------------------------------- | ------------------------------------ |
| Git SCM        | 2.55   | Sistema de controle de versão distribuído.              | https://git-scm.com/downloads/win    |
| GitHub Desktop | Atual  | Interface gráfica para facilitar o uso do Git e GitHub. | https://desktop.github.com/download/ |

### Configuração do Git

```bat
git config --global user.name "Nome do Aluno"
git config --global user.email "email@exemplo.com"
```

Verificar:

```bat
git config --global user.name
git config --global user.email
```

---

# 📐 Modelagem UML e Design

| NOME                    | VERSÃO      | DESCRIÇÃO                                          | LINK                                                                               |
| ----------------------- | ----------- | -------------------------------------------------- | ---------------------------------------------------------------------------------- |
| Astah UML               | Estudante   | Ferramenta para modelagem de diagramas UML.        | https://astah.net/downloads/                                                       |
| Astah Community (64bit) | Falta DER   | Instalador 64 bits via Google Drive.               | https://drive.google.com/file/d/18iAw0ZtNQcWGrqgOmI5w7UIiAetwPR9l/view?usp=sharing |
| drawio                  | Atual       | Desktop.                                           | https://www.drawio.com/                                                            |
| Figma                   | Desktop/Web | Ferramenta de design de interfaces e prototipagem. | https://www.figma.com/pt-br/downloads/                                             |
| Canva                   | Online      | Plataforma de design gráfico online.               | https://www.canva.com/pt_br/baixar/windows/                                        |
| Affinity                | V2          | Suíte de design (Photo).                           | https://www.affinity.studio/pt_br/download                                         |

---

# 🧠 Algoritmos e Programação

| NOME            | VERSÃO | DESCRIÇÃO                                        | LINK                                            |
| --------------- | ------ | ------------------------------------------------ | ----------------------------------------------- |
| VisualG         | 3.0.7  | Interpretador de algoritmos e pseudocódigo.      | https://sourceforge.net/projects/visualg30/     |
| Portugol Studio | Atual  | Ambiente para aprender programação em Português. | https://univali-lite.github.io/Portugol-Studio/ |
| Scratch         | Atual  | Linguagem de programação visual por blocos.      | https://scratch.mit.edu/download                |

---

# 🎨 Edição Gráfica

| NOME     | VERSÃO | DESCRIÇÃO                                                        | LINK                              |
| -------- | ------ | ---------------------------------------------------------------- | --------------------------------- |
| GIMP     | Atual  | Editor de imagens profissional (Alternativa ao Photoshop).       | https://www.gimp.org/downloads/   |
| Inkscape | Atual  | Editor de gráficos vetoriais (Alternativa ao Corel/Illustrator). | https://inkscape.org/release/     |
| Krita    | Atual  | Software de pintura digital e ilustração.                        | https://krita.org/pt-br/download/ |

---

# 🎬 Áudio, Vídeo e Gravação

| NOME       | VERSÃO | DESCRIÇÃO                                             | LINK                                   |
| ---------- | ------ | ----------------------------------------------------- | -------------------------------------- |
| Audacity   | Atual  | Editor e gravador de áudio multi-faixa.               | https://www.audacityteam.org/download/ |
| OBS Studio | Atual  | Software para gravação de tela e transmissão ao vivo. | https://obsproject.com/pt-br/download  |
| Kdenlive   | Atual  | Editor de vídeo não-linear profissional.              | https://kdenlive.org/pt-br/download/   |
| Shotcut    | Atual  | Editor de vídeo gratuito e de código aberto.          | https://www.shotcut.org/download/      |

---

# 🛠️ Utilitários

| NOME        | VERSÃO | DESCRIÇÃO                                 | LINK                                                      |
| ----------- | ------ | ----------------------------------------- | --------------------------------------------------------- |
| 7-Zip       | Atual  | Compactador e descompactador de arquivos. | https://www.7-zip.org/download.html                       |
| Sumatra PDF | Atual  | Leitor de PDF, ePub e Mobi leve e rápido. | https://www.sumatrapdfreader.org/download-free-pdf-viewer |

---

# 🤖 Android Studio, SDK, Emulador e Gradle

## Configuração

O ambiente Android deverá ser configurado para desenvolvimento e execução de projetos utilizando **Java e Kotlin**.

### Componentes

* Android Studio — 2023 (Hedgehog)
* Android SDK
* Android SDK Platform-Tools
* Android SDK Build-Tools
* Android Emulator
* Android Virtual Device (AVD)
* Gradle
* Gradle Wrapper

### Android Studio

https://download2.fileeagle.com/files/2023/12/android-studio-2023.1.1.26-windows.exe

### Testar ADB

```bat
adb version
```

### Listar AVDs

```bat
emulator -list-avds
```

### Verificar dispositivos

```bat
adb devices
```

### Verificar SDK

```bat
echo %ANDROID_HOME%
echo %ANDROID_SDK_ROOT%
```

---

# 🧪 Projetos Android de Teste

Devem ser criados e testados **dois projetos Android** antes do freeze.

---

## 📱 Projeto 1 — Java

### Nome

```text
LaboratorioTesteJava
```

### Configuração

* Linguagem: Java
* Min SDK: API 24
* Activity simples
* Mensagem na tela
* Execução no Android Emulator

### Testes

1. Criar o projeto.
2. Configurar Min SDK API 24.
3. Sincronizar com Gradle.
4. Baixar as dependências.
5. Executar o build.
6. Confirmar ausência de erros.
7. Executar no Emulator.
8. Confirmar instalação.
9. Confirmar inicialização.
10. Alterar uma mensagem.
11. Executar novamente.
12. Confirmar a alteração.

---

## 📱 Projeto 2 — Kotlin

### Nome

```text
LaboratorioTesteKotlin
```

### Configuração

* Linguagem: Kotlin
* Min SDK: API 24
* Activity simples
* Mensagem na tela
* Execução no Android Emulator

### Testes

1. Criar o projeto.
2. Configurar Min SDK API 24.
3. Sincronizar com Gradle.
4. Baixar as dependências.
5. Executar o build.
6. Confirmar ausência de erros.
7. Executar no Emulator.
8. Confirmar instalação.
9. Confirmar inicialização.
10. Alterar uma mensagem.
11. Executar novamente.
12. Confirmar a alteração.

---

# 🔨 Validação do Gradle

Os projetos deverão utilizar o **Gradle Wrapper do próprio projeto**.

Executar no Windows:

```bat
gradlew --version
gradlew clean
gradlew build
```

Também deverá ser realizada a sincronização pelo Android Studio.

O objetivo é garantir que:

* Dependências estejam disponíveis;
* Plugins estejam disponíveis;
* Gradle esteja funcionando;
* Build seja executado;
* APK seja gerado;
* Projeto possa ser executado sem configuração manual adicional.

---

# 🗄️ Configuração dos Serviços de Banco de Dados

Para evitar consumo desnecessário de RAM, recomenda-se configurar os serviços MySQL e PostgreSQL para **não iniciarem automaticamente com o Windows**.

Os serviços poderão ser iniciados manualmente quando forem utilizados.

## Descobrir o nome do serviço

Pressione:

```text
Win + R
```

Digite:

```text
services.msc
```

Procure por:

* MySQL;
* PostgreSQL.

---

## Iniciar MySQL

Exemplo:

```bat
net start MySQL80
```

Parar:

```bat
net stop MySQL80
```

---

## Iniciar PostgreSQL

Exemplo:

```bat
net start postgresql-x64-17
```

Parar:

```bat
net stop postgresql-x64-17
```

> Os nomes dos serviços podem variar conforme a versão instalada.

---

# 🔧 Scripts Windows

## 📌 Iniciar_Bancos.bat

```bat
@echo off
title Iniciar MySQL e PostgreSQL
color 0A

echo ==========================================
echo       INICIANDO SERVICOS DE BANCO
echo ==========================================
echo.

echo Iniciando MySQL...
net start MySQL80

echo.
echo Iniciando PostgreSQL...
net start postgresql-x64-17

echo.
echo ==========================================
echo          SERVICOS INICIADOS
echo ==========================================
echo.

pause
```

---

# 👤 Configurar_Git.bat

```bat
@echo off
title Configuracao do Git
color 0B

echo ==========================================
echo          CONFIGURACAO DO GIT
echo ==========================================
echo.

set /p NOME="Digite seu nome para o Git: "
set /p EMAIL="Digite seu e-mail para o Git: "

echo.
echo Configurando Git...

git config --global user.name "%NOME%"
git config --global user.email "%EMAIL%"

echo.
echo ==========================================
echo       CONFIGURACAO REALIZADA
echo ==========================================
echo.

echo Nome configurado:
git config --global user.name

echo.
echo E-mail configurado:
git config --global user.email

echo.
pause
```

---

# 🔍 Script de Verificação de Versões

Arquivo:

```text
Verificar_Laboratorio.bat
```

O objetivo deste script é verificar rapidamente as versões dos principais ambientes instalados na máquina.

```bat
@echo off
title Verificacao do Laboratorio de Informatica
color 0B

cls

echo ============================================================
echo       LABORATORIO DE INFORMATICA - VERIFICACAO
echo ============================================================
echo.

echo [JAVA]
echo ------------------------------------------------------------
java -version
echo.
javac -version
echo.

echo [PYTHON]
echo ------------------------------------------------------------
python --version
echo.
python -m pip --version
echo.

echo [NODE.JS]
echo ------------------------------------------------------------
node --version
echo.
npm --version
echo.
npx --version
echo.

echo [GIT]
echo ------------------------------------------------------------
git --version
echo.

echo [DOCKER]
echo ------------------------------------------------------------
docker --version
echo.
docker compose version
echo.

echo [VS CODE]
echo ------------------------------------------------------------
code --version
echo.

echo [ANDROID ADB]
echo ------------------------------------------------------------
adb version
echo.

echo [ANDROID EMULATOR]
echo ------------------------------------------------------------
emulator -list-avds
echo.

echo [ANDROID DEVICES]
echo ------------------------------------------------------------
adb devices
echo.

echo [MYSQL]
echo ------------------------------------------------------------
mysql --version
echo.

echo [POSTGRESQL]
echo ------------------------------------------------------------
psql --version
echo.

echo [MONGODB]
echo ------------------------------------------------------------
mongosh --version
echo.

echo ============================================================
echo              VERIFICACAO CONCLUIDA
echo ============================================================
echo.

pause
```

---

# 🧩 Verificação das Extensões do VS Code

Executar:

```bat
code --list-extensions
```

Verificar se estão presentes:

```text
vscjava.vscode-java-pack
vmware.vscode-boot-dev-pack
ms-python.python
ms-python.vscode-pylance
ms-python.debugpy
dbaeumer.vscode-eslint
esbenp.prettier-vscode
waderyan.nodejs-extension-pack
ms-azuretools.vscode-docker
eamodio.gitlens
ritwickdey.LiveServer
ecmel.vscode-html-css
humao.rest-client
formulahendry.code-runner
```

---

# 🧪 Teste Final do Laboratório

Após a instalação de todos os softwares, recomenda-se realizar um teste completo em uma máquina modelo.

## Desenvolvimento

* [ ] VS Code abre corretamente
* [ ] Java JDK funciona
* [ ] Python funciona
* [ ] Node.js funciona
* [ ] Git funciona
* [ ] Docker funciona
* [ ] IntelliJ IDEA funciona
* [ ] PyCharm funciona
* [ ] Code::Blocks funciona
* [ ] Arduino IDE funciona
* [ ] Notepad++ funciona

## VS Code

* [ ] Java Extension Pack
* [ ] Spring Boot Extension Pack
* [ ] Python
* [ ] Pylance
* [ ] Python Debugger
* [ ] ESLint
* [ ] Prettier
* [ ] Node.js Extension Pack
* [ ] Docker
* [ ] GitLens
* [ ] Live Server
* [ ] HTML CSS Support
* [ ] REST Client
* [ ] Code Runner

## Bancos de Dados

* [ ] MySQL
* [ ] MySQL Workbench
* [ ] PostgreSQL
* [ ] pgAdmin
* [ ] MongoDB
* [ ] MongoDB Compass
* [ ] DBeaver
* [ ] Cassandra via Docker

## Android

* [ ] Android Studio
* [ ] Android SDK
* [ ] Platform-Tools
* [ ] Build-Tools
* [ ] Android Emulator
* [ ] AVD
* [ ] Gradle
* [ ] Gradle Wrapper
* [ ] Projeto Java
* [ ] Projeto Kotlin
* [ ] Build Java
* [ ] Build Kotlin
* [ ] Execução Java no Emulator
* [ ] Execução Kotlin no Emulator

## Design

* [ ] Astah
* [ ] draw.io
* [ ] Figma
* [ ] Canva
* [ ] Affinity
* [ ] GIMP
* [ ] Inkscape
* [ ] Krita

## Multimídia

* [ ] Kdenlive
* [ ] Shotcut
* [ ] Audacity
* [ ] OBS Studio

## Utilitários

* [ ] 7-Zip
* [ ] Sumatra PDF

---

# ❄️ Freeze da Imagem

O congelamento da imagem dos computadores somente deverá ocorrer após a conclusão de todos os testes.

## Fluxo recomendado

```text
INSTALAÇÃO
     ↓
CONFIGURAÇÃO
     ↓
ATUALIZAÇÃO
     ↓
VERIFICAÇÃO DE VERSÕES
     ↓
TESTE DOS SOFTWARES
     ↓
TESTE DOS BANCOS
     ↓
TESTE DO VS CODE
     ↓
TESTE ANDROID JAVA
     ↓
TESTE ANDROID KOTLIN
     ↓
TESTE GRADLE
     ↓
TESTE EMULADOR
     ↓
TESTE GERAL
     ↓
VALIDAÇÃO DA MÁQUINA MODELO
     ↓
FREEZE
     ↓
REPLICAÇÃO DA IMAGEM
```

---

# ⚠️ Objetivo do Freeze

A finalidade do freeze é garantir que:

* Dependências do Gradle estejam previamente baixadas;
* Plugins estejam disponíveis;
* Android SDK esteja configurado;
* Build-Tools estejam instalados;
* Platform-Tools estejam instalados;
* AVD esteja criado;
* Projetos Java e Kotlin tenham sido testados;
* Bancos de dados estejam funcionando;
* Extensões do VS Code estejam instaladas;
* Ferramentas necessárias estejam disponíveis localmente.

Dessa forma, reduz-se a necessidade de downloads e configurações durante as aulas.

Também são reduzidos problemas relacionados a:

* Internet;
* Proxy;
* Firewall;
* Permissões;
* Repositórios indisponíveis;
* Downloads bloqueados;
* Configurações manuais.

---

# 📊 Critérios de Aprovação

| COMPONENTE        | STATUS |
| ----------------- | ------ |
| Java JDK 21       | ⬜      |
| Python 3.13       | ⬜      |
| Node.js 22        | ⬜      |
| Git               | ⬜      |
| Docker            | ⬜      |
| VS Code           | ⬜      |
| Extensões VS Code | ⬜      |
| MySQL             | ⬜      |
| PostgreSQL        | ⬜      |
| MongoDB           | ⬜      |
| DBeaver           | ⬜      |
| Android Studio    | ⬜      |
| Android SDK       | ⬜      |
| Platform-Tools    | ⬜      |
| Build-Tools       | ⬜      |
| Emulator          | ⬜      |
| AVD               | ⬜      |
| Gradle            | ⬜      |
| Projeto Java      | ⬜      |
| Projeto Kotlin    | ⬜      |
| Astah             | ⬜      |
| draw.io           | ⬜      |
| GIMP              | ⬜      |
| Inkscape          | ⬜      |
| Krita             | ⬜      |
| Kdenlive          | ⬜      |
| Shotcut           | ⬜      |
| Audacity          | ⬜      |
| OBS Studio        | ⬜      |
| 7-Zip             | ⬜      |
| Sumatra PDF       | ⬜      |

---

# ✅ Checklist Final

Antes do freeze:

```text
[ ] Softwares instalados
[ ] Versões conferidas
[ ] Links documentados
[ ] VS Code instalado
[ ] Extensões instaladas
[ ] Java funcionando
[ ] Python funcionando
[ ] Node.js funcionando
[ ] Git funcionando
[ ] Docker funcionando
[ ] MySQL funcionando
[ ] PostgreSQL funcionando
[ ] MongoDB funcionando
[ ] DBeaver funcionando
[ ] Android Studio funcionando
[ ] Android SDK configurado
[ ] Platform-Tools funcionando
[ ] Build-Tools instalados
[ ] Emulator funcionando
[ ] AVD criado
[ ] Gradle funcionando
[ ] Gradle Wrapper funcionando
[ ] Projeto Android Java criado
[ ] Projeto Android Kotlin criado
[ ] Projeto Java compilado
[ ] Projeto Kotlin compilado
[ ] Aplicativo Java executado
[ ] Aplicativo Kotlin executado
[ ] Dependências baixadas
[ ] Extensões VS Code testadas
[ ] Bancos testados
[ ] Ferramentas gráficas testadas
[ ] Ferramentas multimídia testadas
[ ] Script de verificação executado
[ ] Máquina modelo validada
[ ] Freeze realizado
[ ] Imagem replicada
```

---

# 📝 Observações

Este documento deve ser utilizado como referência para a preparação da **máquina modelo** do Laboratório de Informática.

Sempre que houver alteração significativa nas versões dos softwares, recomenda-se:

1. Atualizar este documento;
2. Preparar uma nova máquina modelo;
3. Instalar as novas versões;
4. Executar o script de verificação;
5. Testar os bancos de dados;
6. Testar as extensões do VS Code;
7. Testar o Android Studio;
8. Testar os projetos Java e Kotlin;
9. Testar o Gradle;
10. Testar o Emulator;
11. Validar todos os softwares;
12. Somente depois realizar o novo freeze.

---

# 🏫 Informações do Laboratório

**Responsável:** `[Seu nome]`

**Curso/Disciplina:** `[Curso/Disciplina]`

**Instituição:** `[Instituição]`

**Laboratório:** `[Nome/Número do laboratório]`

**Sistema Operacional:** Windows 10/11

**Arquitetura:** 64 bits

**Última atualização:** 2026

---

## 📌 Versão do Documento

```text
Documento: Laboratório de Informática
Versão: 1.0
Ano: 2026
Finalidade: Instalação, configuração, testes e freeze
```

---

> **✅ Após a validação completa da máquina modelo, esta configuração deverá ser utilizada como referência para a replicação nos demais computadores do laboratório.**
